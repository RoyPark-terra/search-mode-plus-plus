---
name: search-mode-local-config
description: Keep non-sensitive Search Mode ++ connection settings in the plugin-local storage file.
---

# Search Mode ++ local configuration

Use `storage/search-mode.local.json` as the local source of truth for the Search Mode ++ MCP server name and URL.

- Keep the MCP endpoint synchronized with `.mcp.json`.
- Do not store API keys, OAuth tokens, cookies, passwords, or other secrets in this file.
- If authentication is required, use the Codex/MCP authentication flow or a machine-provided secret instead of writing credentials into the plugin.
- Preserve this file when updating or reinstalling the plugin from its local source.
