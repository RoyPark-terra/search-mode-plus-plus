import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const pluginRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const readJson = (relativePath) => JSON.parse(fs.readFileSync(path.join(pluginRoot, relativePath), "utf8"));
const requiredFiles = [
  ".codex-plugin/plugin.json",
  ".mcp.json",
  "storage/search-mode.local.json",
  "skills/searchmode/SKILL.md",
  "skills/searchmode/agents/openai.yaml",
  "skills/searchmode/assets/icon.svg",
  "upstream/SearchMode_260827_GPT.txt",
  "upstream/LICENSE",
  "docs/ARCHITECTURE.md",
  "docs/UPSTREAM.md",
];

const manifest = readJson(".codex-plugin/plugin.json");
const mcp = readJson(".mcp.json");
const local = readJson("storage/search-mode.local.json");
const endpoint = mcp.mcpServers?.["search-mode"]?.url;

const missing = requiredFiles.filter((relativePath) => !fs.existsSync(path.join(pluginRoot, relativePath)));
if (missing.length) {
  throw new Error(`Missing required files: ${missing.join(", ")}`);
}
if (manifest.name !== "search-mode-plus-plus") {
  throw new Error(`Unexpected plugin name: ${manifest.name}`);
}
if (!endpoint || endpoint !== local.mcpServer?.url) {
  throw new Error("The MCP endpoint is not synchronized between .mcp.json and local storage.");
}
if (local.remoteIsOptional !== true) {
  throw new Error("The remote MCP connection must remain marked optional.");
}

console.log("Local Search Mode ++ check passed.");
console.log(`Plugin: ${manifest.name} v${manifest.version}`);
console.log(`Local fallback: ${local.localFallback}`);
console.log(`Optional MCP: ${endpoint}`);
