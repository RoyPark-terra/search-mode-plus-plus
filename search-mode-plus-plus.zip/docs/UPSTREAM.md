# Upstream and provenance

## Public source

- Repository: https://github.com/lemos999/SearchMode-Prompt-
- Snapshot commit checked: `7deb48acb42e863f75d69e6cb1978af9db43d756`
- License: MIT; see `upstream/LICENSE`.
- Vendored GPT prompt: `upstream/SearchMode_260827_GPT.txt`
- Vendored Codex skill: `skills/searchmode/SKILL.md`

## Related public posts

- Patch history: https://gall.dcinside.com/mgallery/board/view/?id=thesingularity&no=1347102&page=1
- Search Mode ++ MCP distribution: https://gall.dcinside.com/mgallery/board/view/?id=thesingularity&no=1376481&exception_mode=recommend&search_head=120&page=1
- Prompt archive: https://gall.dcinside.com/mgallery/board/view/?id=thesingularity&no=907541&exception_mode=recommend&search_head=120&page=1

## MCP endpoint checked

`https://search-mode-test.search-mode-test.workers.dev/mcp`

The endpoint responded to MCP initialization and advertised the server name `search-mode-test`, version `0.1.4`, plus three server tools observed during the check:

- `search_mode_test_required_first_step`
- `search_mode_test_deep_research_cycle_checkpoint`
- `search_mode_test_deep_research_finalize`

The endpoint is therefore reachable at the time recorded in the task, but reachability is not a guarantee of future availability. Its Worker implementation is not included in the public GitHub repository inspected for this package.

## Attribution

The prompt and skill files are preserved for personal/local operation under their upstream MIT license. Changes in this plugin are packaging, local persistence, documentation, and fallback wiring.
