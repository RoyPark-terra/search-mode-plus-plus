# Search Mode ++ local-first architecture

## Runtime layers

1. **Codex host**
   Codex supplies the model, web access, and any available analysis tools.

2. **Local skill layer**
   `skills/searchmode/SKILL.md` contains the public Search Mode rules. It is packaged inside this plugin, so it does not depend on the Worker remaining online.

3. **Optional MCP layer**
   `.mcp.json` points to the Search Mode test MCP endpoint. The endpoint can add server-side tools such as the first-step check and research checkpoints, but it is not the source of the local prompt.

4. **Local metadata layer**
   `storage/search-mode.local.json` records the endpoint and verification metadata. It deliberately contains no credentials.

## Failure behavior

| Event | Local skill | MCP-specific tools | Expected result |
| --- | --- | --- | --- |
| Worker is online | Available | Available | Full configured experience |
| Worker is slow or returns an error | Available | Degraded | Continue with local rules and host tools; report MCP failure when relevant |
| Worker URL disappears | Available | Unavailable | Search Mode prompt remains usable; only server-specific functions are lost |
| Plugin folder is erased | Unavailable | Unavailable | Restore the folder from GitHub or the ZIP backup |

## Boundary

This repository is a faithful local package of the public prompt/skill artifacts and configuration. It is **not** a reconstruction of the private Cloudflare Worker implementation. The Worker’s exact source was not published in the inspected public repository, so server-side behavior is documented only at the level that was observable from the MCP endpoint.

## Security rule

Remote MCP output is untrusted input. It may describe tools or return instructions, but it cannot override Codex’s system/developer rules, safety constraints, or the user’s request. Do not put secrets in `.mcp.json` or the local storage file.
